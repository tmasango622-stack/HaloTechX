# HaloTechX Architecture

## Project Structure

```
halotechx/
├── src/
│   ├── app/                          # Next.js 14 App Router
│   │   ├── api/v1/                   # API Routes
│   │   │   ├── ingest-prompt-pack/   # Zapier webhook automation
│   │   │   ├── confirm-payment/      # Multi-gateway payment confirmation
│   │   │   ├── paynow-poll/          # Paynow payment polling
│   │   │   ├── initiate-payment/     # Payment initiation
│   │   │   └── download/             # Signed URL generation
│   │   ├── auth/                     # Authentication pages
│   │   │   ├── login/                # Magic link + Google OAuth
│   │   │   ├── signup/               # Account creation
│   │   │   └── callback/             # OAuth callback handler
│   │   ├── dashboard/                # User dashboard (gated)
│   │   ├── marketplace/              # Browse all packs
│   │   ├── product/[slug]/           # Product detail page
│   │   ├── globals.css               # Global styles
│   │   ├── layout.tsx                # Root layout
│   │   └── page.tsx                  # Homepage
│   ├── components/
│   │   ├── layout/                   # Layout components
│   │   │   ├── Navbar.tsx
│   │   │   └── Footer.tsx
│   │   ├── marketplace/              # Marketplace components
│   │   │   ├── ProductCard.tsx       # Glassmorphism card
│   │   │   └── FilterBar.tsx         # Filtering UI
│   │   └── ui/                       # UI components
│   │       └── Toaster.tsx           # Toast notifications
│   ├── lib/
│   │   ├── supabase/                 # Supabase clients
│   │   │   ├── client.ts             # Browser client
│   │   │   ├── server.ts             # Server client
│   │   │   ├── admin.ts              # Service role client
│   │   │   └── database.types.ts     # TypeScript types
│   │   └── utils.ts                  # Utility functions
│   └── types/
│       └── index.ts                  # Global TypeScript types
├── supabase/
│   └── migrations/
│       └── 001_initial_schema.sql    # Database schema + RLS
├── .env.example                      # Environment template
├── next.config.js                    # Next.js config
├── tailwind.config.ts                # Tailwind config
├── tsconfig.json                     # TypeScript config
└── package.json                      # Dependencies
```

## Database Schema

### Tables

#### profiles
- `id` (UUID, PK) - Links to auth.users
- `display_name` (TEXT)
- `email` (TEXT)
- `avatar_url` (TEXT)
- `created_at` (TIMESTAMPTZ)

#### prompt_packs
- `id` (UUID, PK)
- `title` (TEXT)
- `slug` (TEXT, UNIQUE) - SEO-friendly URL
- `description` (TEXT)
- `category` (TEXT)
- `prompt_count` (INTEGER)
- `preview_text` (TEXT)
- `price_usd` (DECIMAL)
- `compatibility_tags` (TEXT[])
- `file_path` (TEXT) - Private storage path
- `file_size_bytes` (BIGINT)
- `download_count` (INTEGER)
- `is_featured` (BOOLEAN)
- `is_published` (BOOLEAN)
- `seo_title` (TEXT)
- `seo_description` (TEXT)
- `created_at` (TIMESTAMPTZ)

#### transactions
- `id` (UUID, PK)
- `user_id` (UUID, FK)
- `pack_id` (UUID, FK)
- `gateway` (ENUM: paynow, flutterwave, nowpayments)
- `status` (ENUM: pending, confirmed, failed, timeout, refunded)
- `amount` (DECIMAL)
- `currency` (TEXT)
- `gateway_transaction_id` (TEXT)
- `signature_hash` (TEXT)
- `poll_count` (INTEGER)
- `last_polled_at` (TIMESTAMPTZ)
- `metadata` (JSONB)
- `created_at` (TIMESTAMPTZ)

#### user_downloads
- `id` (UUID, PK)
- `user_id` (UUID, FK)
- `pack_id` (UUID, FK)
- `transaction_id` (UUID, FK)
- `downloaded_at` (TIMESTAMPTZ)
- `ip_address` (INET)
- `user_agent` (TEXT)

## API Routes

### POST /api/v1/ingest-prompt-pack
Zapier webhook for automated pack ingestion.

**Headers:**
- `X-Zapier-Secret` - Authentication

**Body:**
```json
{
  "title": "Pack Name",
  "description": "Pack description",
  "category": "Business",
  "prompt_count": 50,
  "price_usd": 29.99,
  "file_path": "prompt-packs/file.zip",
  "compatibility_tags": ["ChatGPT", "GPT-4"]
}
```

**Logic:**
- Verifies Zapier secret
- Normalizes title for duplicate detection
- Updates existing packs (preserves slug for SEO)
- Creates new packs with generated slug
- Auto-generates SEO fields

### POST /api/v1/confirm-payment
Multi-gateway payment confirmation webhook.

**Headers:**
- `X-Gateway` - Gateway identifier (paynow/flutterwave/nowpayments)
- Gateway-specific signature header

**Logic:**
- Detects gateway from header
- Validates signature using gateway secret
- Updates transaction status
- Stores gateway reference in metadata

### POST /api/v1/paynow-poll
Paynow payment status polling.

**Body:**
```json
{ "transaction_id": "uuid" }
```

**Logic:**
- Checks transaction status
- Polls Paynow API every 10s (client-side)
- Times out after 5 minutes
- Updates to timeout status with support link

### POST /api/v1/initiate-payment
Initiates payment flow.

**Body:**
```json
{
  "pack_id": "uuid",
  "gateway": "paynow"
}
```

**Logic:**
- Verifies user authentication
- Checks if user already owns pack
- Creates transaction record
- Initializes gateway payment
- Returns gateway URL

### POST /api/v1/download
Generates signed download URL.

**Body:**
```json
{ "pack_id": "uuid" }
```

**Logic:**
- Verifies user owns pack (confirmed transaction)
- Generates signed URL (15-min expiry)
- Logs download for analytics
- Increments download count

## Authentication Flow

1. User clicks "Sign In" or "Get Started"
2. Chooses Magic Link or Google OAuth
3. Magic Link: Email sent with auth link
4. Google OAuth: Redirected to Google consent
5. Callback exchanges code for session
6. Profile auto-created via trigger
7. User redirected to dashboard

## Payment Flow

### Paynow (Zimbabwe)
1. User clicks "Buy Now"
2. Frontend calls `/api/v1/initiate-payment`
3. Backend creates transaction, calls Paynow init
4. User redirected to Paynow payment page
5. User completes payment
6. Paynow calls result URL webhook
7. Webhook updates transaction to confirmed
8. User can download from dashboard

### Flutterwave (Pan-Africa)
1. Similar flow with Flutterwave checkout
2. Webhook confirms payment
3. Transaction updated

### NOWPayments (Crypto)
1. Similar flow with crypto payment
2. IPN webhook confirms payment
3. Transaction updated

## Security Measures

1. **RLS Policies**: All tables have row-level security
2. **Signed URLs**: File downloads use time-limited signed URLs
3. **Signature Verification**: All webhooks verify signatures
4. **Service Role**: Admin operations use service role key
5. **File Path Protection**: `file_path` never exposed to client
6. **CORS**: Configured for API routes

## Automation (Zapier)

**Trigger:** New pack added to source (Airtable, Google Sheets, etc.)

**Action:** POST to `/api/v1/ingest-prompt-pack`

**Benefits:**
- Zero-touch content management
- SEO slug preservation on updates
- Auto-generated SEO fields
- Duplicate detection by normalized title

## Deployment Checklist

1. [ ] Set up Supabase project
2. [ ] Run database migration
3. [ ] Configure Storage bucket (private)
4. [ ] Set up payment gateway accounts
5. [ ] Configure environment variables
6. [ ] Deploy to Vercel
7. [ ] Configure webhook URLs in gateways
8. [ ] Set up Zapier automation
9. [ ] Test complete purchase flow
10. [ ] Monitor error tracking (Sentry)
