-- ============================================
-- HaloTechX Database Schema
-- AI Prompt Packs Marketplace
-- ============================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- PROFILES TABLE
-- Stores user profile information linked to auth.users
-- ============================================
CREATE TABLE profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    display_name TEXT,
    email TEXT NOT NULL,
    avatar_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create index on email for faster lookups
CREATE INDEX idx_profiles_email ON profiles(email);

-- ============================================
-- PROMPT_PACKS TABLE
-- Stores AI prompt pack products
-- ============================================
CREATE TABLE prompt_packs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    description TEXT NOT NULL,
    category TEXT NOT NULL,
    prompt_count INTEGER NOT NULL DEFAULT 0,
    preview_text TEXT,
    price_usd DECIMAL(10, 2) NOT NULL,
    compatibility_tags TEXT[] DEFAULT '{}',
    file_path TEXT NOT NULL, -- Private Supabase Storage path
    file_size_bytes BIGINT,
    download_count INTEGER DEFAULT 0,
    is_featured BOOLEAN DEFAULT FALSE,
    is_published BOOLEAN DEFAULT TRUE,
    seo_title TEXT,
    seo_description TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes for common queries
CREATE INDEX idx_prompt_packs_category ON prompt_packs(category);
CREATE INDEX idx_prompt_packs_price ON prompt_packs(price_usd);
CREATE INDEX idx_prompt_packs_featured ON prompt_packs(is_featured) WHERE is_featured = TRUE;
CREATE INDEX idx_prompt_packs_published ON prompt_packs(is_published) WHERE is_published = TRUE;
CREATE INDEX idx_prompt_packs_created ON prompt_packs(created_at DESC);
CREATE INDEX idx_prompt_packs_compatibility ON prompt_packs USING GIN(compatibility_tags);

-- Full-text search index
CREATE INDEX idx_prompt_packs_search ON prompt_packs 
    USING gin(to_tsvector('english', title || ' ' || COALESCE(description, '')));

-- ============================================
-- TRANSACTIONS TABLE
-- Stores payment transactions
-- ============================================
CREATE TYPE payment_status AS ENUM ('pending', 'confirmed', 'failed', 'timeout', 'refunded');
CREATE TYPE payment_gateway AS ENUM ('paynow', 'flutterwave', 'nowpayments');

CREATE TABLE transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    pack_id UUID REFERENCES prompt_packs(id) ON DELETE SET NULL,
    gateway payment_gateway NOT NULL,
    status payment_status DEFAULT 'pending',
    amount DECIMAL(12, 2) NOT NULL,
    currency TEXT NOT NULL DEFAULT 'USD',
    gateway_transaction_id TEXT,
    signature_hash TEXT, -- For webhook verification
    poll_count INTEGER DEFAULT 0,
    last_polled_at TIMESTAMPTZ,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes for transaction queries
CREATE INDEX idx_transactions_user ON transactions(user_id);
CREATE INDEX idx_transactions_pack ON transactions(pack_id);
CREATE INDEX idx_transactions_status ON transactions(status);
CREATE INDEX idx_transactions_gateway_tx ON transactions(gateway_transaction_id);
CREATE INDEX idx_transactions_created ON transactions(created_at DESC);

-- ============================================
-- USER_DOWNLOADS TABLE
-- Tracks user downloads for analytics and security
-- ============================================
CREATE TABLE user_downloads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    pack_id UUID REFERENCES prompt_packs(id) ON DELETE CASCADE,
    transaction_id UUID REFERENCES transactions(id) ON DELETE CASCADE,
    downloaded_at TIMESTAMPTZ DEFAULT NOW(),
    ip_address INET,
    user_agent TEXT
);

CREATE INDEX idx_user_downloads_user ON user_downloads(user_id);
CREATE INDEX idx_user_downloads_pack ON user_downloads(pack_id);
CREATE INDEX idx_user_downloads_transaction ON user_downloads(transaction_id);

-- ============================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE prompt_packs ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_downloads ENABLE ROW LEVEL SECURITY;

-- ============================================
-- PROFILES RLS POLICIES
-- ============================================

-- Users can only read their own profile
CREATE POLICY "Users can read own profile"
    ON profiles FOR SELECT
    USING (auth.uid() = id);

-- Users can only update their own profile
CREATE POLICY "Users can update own profile"
    ON profiles FOR UPDATE
    USING (auth.uid() = id);

-- Allow insert during signup (trigger handles this)
CREATE POLICY "Allow insert during signup"
    ON profiles FOR INSERT
    WITH CHECK (auth.uid() = id);

-- ============================================
-- PROMPT_PACKS RLS POLICIES
-- ============================================

-- Anyone can read published packs
CREATE POLICY "Anyone can read published packs"
    ON prompt_packs FOR SELECT
    USING (is_published = TRUE);

-- Only service role can insert/update/delete (via API)
CREATE POLICY "Service role can manage packs"
    ON prompt_packs FOR ALL
    USING (auth.role() = 'service_role')
    WITH CHECK (auth.role() = 'service_role');

-- ============================================
-- TRANSACTIONS RLS POLICIES
-- ============================================

-- Users can only read their own transactions
CREATE POLICY "Users can read own transactions"
    ON transactions FOR SELECT
    USING (auth.uid() = user_id);

-- Service role can manage all transactions
CREATE POLICY "Service role can manage transactions"
    ON transactions FOR ALL
    USING (auth.role() = 'service_role')
    WITH CHECK (auth.role() = 'service_role');

-- ============================================
-- USER_DOWNLOADS RLS POLICIES
-- ============================================

-- Users can only read their own downloads
CREATE POLICY "Users can read own downloads"
    ON user_downloads FOR SELECT
    USING (auth.uid() = user_id);

-- Service role can insert downloads
CREATE POLICY "Service role can insert downloads"
    ON user_downloads FOR INSERT
    WITH CHECK (auth.role() = 'service_role');

-- ============================================
-- FUNCTIONS & TRIGGERS
-- ============================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply updated_at trigger to all tables
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_prompt_packs_updated_at BEFORE UPDATE ON prompt_packs
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_transactions_updated_at BEFORE UPDATE ON transactions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to create profile on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, email, display_name)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email)
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to create profile on signup
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Function to increment download count
CREATE OR REPLACE FUNCTION increment_download_count(pack_id UUID)
RETURNS VOID AS $$
BEGIN
    UPDATE prompt_packs
    SET download_count = download_count + 1
    WHERE id = pack_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- STORAGE BUCKETS
-- ============================================

-- Create private bucket for prompt pack files
INSERT INTO storage.buckets (id, name, public)
VALUES ('prompt-packs', 'prompt-packs', FALSE)
ON CONFLICT (id) DO NOTHING;

-- Storage RLS policies
CREATE POLICY "Allow authenticated users to read their own downloads"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'prompt-packs' AND auth.role() = 'authenticated');

CREATE POLICY "Allow service role to upload files"
    ON storage.objects FOR INSERT
    WITH CHECK (bucket_id = 'prompt-packs' AND auth.role() = 'service_role');

-- ============================================
-- SEED DATA (Sample Packs)
-- ============================================

INSERT INTO prompt_packs (title, slug, description, category, prompt_count, preview_text, price_usd, compatibility_tags, file_path, is_featured, seo_title, seo_description)
VALUES 
    (
        'ChatGPT Business Mastery Pack',
        'chatgpt-business-mastery-pack-a1b2c3',
        '50+ professionally crafted prompts to supercharge your business operations, marketing, and customer engagement using ChatGPT.',
        'Business',
        50,
        'Example: "Act as a marketing strategist. Create a 30-day content calendar for [your industry] targeting [your audience]. Include daily post ideas with specific angles and call-to-actions."',
        29.99,
        ARRAY['ChatGPT', 'GPT-4', 'Claude'],
        'prompt-packs/business-mastery.zip',
        TRUE,
        'ChatGPT Business Mastery Pack - 50+ AI Prompts for Business Growth',
        'Supercharge your business with 50+ professionally crafted ChatGPT prompts. Perfect for marketing, operations, and customer engagement.'
    ),
    (
        'Midjourney Art Styles Collection',
        'midjourney-art-styles-collection-d4e5f6',
        '100+ artistic style prompts to transform your Midjourney creations. From photorealistic to abstract, unlock unlimited creative possibilities.',
        'Creative',
        100,
        'Example: "A serene Japanese garden in the style of Monet impressionism, soft pastel colors, dappled sunlight filtering through cherry blossoms, oil painting texture --ar 16:9"',
        39.99,
        ARRAY['Midjourney', 'DALL-E', 'Stable Diffusion'],
        'prompt-packs/midjourney-art-styles.zip',
        TRUE,
        'Midjourney Art Styles Collection - 100+ Creative AI Prompts',
        'Transform your AI art with 100+ Midjourney style prompts. From photorealistic to abstract, unlock unlimited creative possibilities.'
    ),
    (
        'Code Assistant Pro Pack',
        'code-assistant-pro-pack-g7h8i9',
        '75+ developer-focused prompts for debugging, code review, architecture decisions, and learning new technologies faster.',
        'Development',
        75,
        'Example: "Review this [language] code for best practices, potential bugs, and performance optimizations. Provide specific line-by-line feedback and refactored suggestions."',
        34.99,
        ARRAY['ChatGPT', 'Claude', 'GitHub Copilot'],
        'prompt-packs/code-assistant-pro.zip',
        FALSE,
        'Code Assistant Pro Pack - 75+ AI Prompts for Developers',
        'Level up your coding with 75+ developer-focused AI prompts. Perfect for debugging, code review, and learning new technologies.'
    ),
    (
        'SEO Content Writing Toolkit',
        'seo-content-writing-toolkit-j0k1l2',
        '60+ prompts designed to create SEO-optimized content that ranks. From blog posts to product descriptions, dominate search results.',
        'Marketing',
        60,
        'Example: "Write a 2000-word SEO-optimized blog post about [topic]. Include H2/H3 headings, meta description, internal linking suggestions, and LSI keywords naturally integrated."',
        24.99,
        ARRAY['ChatGPT', 'Claude', 'Jasper'],
        'prompt-packs/seo-content-toolkit.zip',
        TRUE,
        'SEO Content Writing Toolkit - 60+ AI Prompts for Search Rankings',
        'Create SEO-optimized content that ranks with 60+ AI prompts. Perfect for blogs, product descriptions, and search domination.'
    ),
    (
        'Data Analysis & Visualization Guide',
        'data-analysis-visualization-guide-m3n4o5',
        '45+ prompts for extracting insights, creating visualizations, and presenting data stories that drive decision-making.',
        'Data Science',
        45,
        'Example: "Analyze this dataset [describe data] and identify 5 key insights. Suggest appropriate visualizations for each insight and write Python code using matplotlib/seaborn."',
        44.99,
        ARRAY['ChatGPT', 'Claude', 'Code Interpreter'],
        'prompt-packs/data-analysis-guide.zip',
        FALSE,
        'Data Analysis & Visualization Guide - 45+ AI Prompts for Insights',
        'Extract powerful insights with 45+ data analysis AI prompts. Create visualizations and data stories that drive decisions.'
    );

-- ============================================
-- COMPLETION
-- ============================================
COMMENT ON TABLE profiles IS 'User profiles linked to Supabase Auth';
COMMENT ON TABLE prompt_packs IS 'AI prompt pack products available for purchase';
COMMENT ON TABLE transactions IS 'Payment transactions for prompt pack purchases';
COMMENT ON TABLE user_downloads IS 'Download tracking for security and analytics';
