# HaloTechX

A secure, automated, globally accessible SaaS marketplace for AI prompt packs. Built with Next.js 14, Supabase, and multi-rail payment processing.

## Features

- **Modern SaaS UI**: Minimalist dark theme with glassmorphism cards (Linear/Vercel inspired)
- **Multi-Rail Payments**: Paynow (Zimbabwe), Flutterwave (Pan-Africa), NOWPayments (Crypto)
- **Automated Content**: Zapier webhook integration for seamless pack ingestion
- **Secure Downloads**: Signed URLs with 15-minute expiry, never cached
- **Row Level Security**: Comprehensive RLS policies on all database tables
- **SEO Optimized**: Auto-generated meta tags and slugs for all packs

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Database & Auth**: Supabase (Postgres + Auth + RLS)
- **File Storage**: Supabase Storage (Private buckets + Signed URLs)
- **Styling**: Tailwind CSS + Custom Design System
- **Deployment**: Vercel

## Quick Start

1. **Clone and Install**
   ```bash
   git clone <repo>
   cd halotechx
   npm install
   ```

2. **Environment Setup**
   ```bash
   cp .env.example .env.local
   # Fill in all required environment variables
   ```

3. **Database Setup**
   - Run the migration file in Supabase SQL Editor: `supabase/migrations/001_initial_schema.sql`
   - Configure Storage bucket "prompt-packs" as private

4. **Run Development Server**
   ```bash
   npm run dev
   ```

## Environment Variables

See `.env.example` for complete list. Key variables:

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

# Payment Gateways
PAYNOW_INTEGRATION_ID=
PAYNOW_INTEGRATION_KEY=
FLUTTERWAVE_PUBLIC_KEY=
FLUTTERWAVE_SECRET_KEY=
NOWPAYMENTS_API_KEY=

# Security
ZAPIER_WEBHOOK_SECRET=
```

## API Endpoints

### Webhooks
- `POST /api/v1/ingest-prompt-pack` - Zapier automation webhook
- `POST /api/v1/confirm-payment` - Multi-gateway payment confirmation
- `POST /api/v1/paynow-poll` - Paynow payment status polling

### User Actions
- `POST /api/v1/initiate-payment` - Start payment flow
- `POST /api/v1/download` - Generate signed download URL

## Database Schema

### Tables
- **profiles**: User profiles linked to auth.users
- **prompt_packs**: AI prompt pack products
- **transactions**: Payment transactions
- **user_downloads**: Download tracking for analytics

### RLS Policies
All tables have Row Level Security enabled with appropriate policies for user data protection.

## Payment Flow

1. User selects pack and clicks "Buy Now"
2. Frontend calls `/api/v1/initiate-payment`
3. Backend creates transaction record and initializes gateway
4. User completes payment on gateway
5. Gateway webhook calls `/api/v1/confirm-payment`
6. Transaction status updated to "confirmed"
7. User can download from dashboard

## Automation (Zapier)

The `/api/v1/ingest-prompt-pack` endpoint accepts:
- `X-Zapier-Secret` header for authentication
- Pack data with title, description, price, etc.
- Upsert logic: updates existing packs by normalized title, preserves slug for SEO

## Security Features

- Signature verification for all payment webhooks
- Signed URLs for file downloads (15-min expiry)
- RLS policies prevent unauthorized data access
- `file_path` never exposed to client
- Service role only for admin operations

## License

MIT License - See LICENSE file for details.
