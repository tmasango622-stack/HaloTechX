import Link from 'next/link';
import { createAdminClient } from '@/lib/supabase/admin';
import { ProductCard } from '@/components/marketplace/ProductCard';
import { ArrowRight, Zap, Shield, Globe, Sparkles, CheckCircle, Download } from 'lucide-react';

async function getFeaturedPacks() {
  const supabase = createAdminClient();
  const { data: packs } = await supabase
    .from('prompt_packs')
    .select('*')
    .eq('is_featured', true)
    .eq('is_published', true)
    .order('created_at', { ascending: false })
    .limit(4);
  return packs || [];
}

export default async function HomePage() {
  const featuredPacks = await getFeaturedPacks();

  const compatibilityModels = [
    'ChatGPT',
    'GPT-4',
    'Claude',
    'Midjourney',
    'DALL-E',
    'Stable Diffusion',
  ];

  const howItWorks = [
    {
      icon: Zap,
      title: 'Browse & Discover',
      description: 'Explore our curated collection of AI prompt packs for every use case.',
    },
    {
      icon: Shield,
      title: 'Secure Purchase',
      description: 'Buy with confidence using Paynow, Flutterwave, or crypto payments.',
    },
    {
      icon: Download,
      title: 'Instant Access',
      description: 'Download your prompts immediately and start using them right away.',
    },
  ];

  const stats = [
    { value: '500+', label: 'AI Prompts' },
    { value: '10K+', label: 'Downloads' },
    { value: '50+', label: 'Countries' },
    { value: '99%', label: 'Satisfaction' },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-transparent" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-primary/10 rounded-full blur-[150px] -translate-y-1/2" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-32">
          <div className="text-center max-w-4xl mx-auto">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/30 text-primary text-sm font-medium mb-8">
              <Sparkles className="w-4 h-4" />
              <span>Now accepting Paynow, Flutterwave & Crypto</span>
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold text-text-primary mb-6 leading-tight">
              Supercharge Your{' '}
              <span className="gradient-text">AI Workflow</span>
            </h1>

            {/* Subheadline */}
            <p className="text-lg sm:text-xl text-text-secondary mb-8 max-w-2xl mx-auto">
              Professionally crafted prompt packs for ChatGPT, Midjourney, Claude, and more. 
              Save hours of experimentation and get results instantly.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
              <Link
                href="/marketplace"
                className="w-full sm:w-auto px-8 py-4 bg-primary hover:bg-primary-hover text-white font-semibold rounded-xl transition-all flex items-center justify-center gap-2 glow-primary"
              >
                Explore Marketplace
                <ArrowRight className="w-5 h-5" />
              </Link>
              <Link
                href="/auth/signup"
                className="w-full sm:w-auto px-8 py-4 bg-surface-light hover:bg-border text-text-primary font-semibold rounded-xl transition-all border border-border"
              >
                Create Free Account
              </Link>
            </div>

            {/* Model Compatibility Bar */}
            <div className="flex flex-wrap items-center justify-center gap-3">
              <span className="text-text-muted text-sm">Compatible with:</span>
              {compatibilityModels.map((model) => (
                <span
                  key={model}
                  className="px-3 py-1 bg-surface-light border border-border rounded-full text-sm text-text-secondary"
                >
                  {model}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="border-y border-border bg-surface/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-3xl sm:text-4xl font-bold text-text-primary mb-1">
                  {stat.value}
                </div>
                <div className="text-text-secondary text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Packs Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between mb-12">
            <div>
              <h2 className="text-3xl sm:text-4xl font-bold text-text-primary mb-4">
                Featured Packs
              </h2>
              <p className="text-text-secondary max-w-xl">
                Hand-picked prompt packs loved by our community. Start with these proven winners.
              </p>
            </div>
            <Link
              href="/marketplace"
              className="hidden sm:flex items-center gap-2 text-primary hover:text-primary-hover font-medium transition-colors"
            >
              View All
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredPacks.map((pack) => (
              <ProductCard key={pack.id} pack={pack} showBadge />
            ))}
          </div>

          <div className="mt-8 text-center sm:hidden">
            <Link
              href="/marketplace"
              className="inline-flex items-center gap-2 text-primary hover:text-primary-hover font-medium"
            >
              View All Packs
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-24 bg-surface/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-text-primary mb-4">
              How It Works
            </h2>
            <p className="text-text-secondary max-w-xl mx-auto">
              Get started in minutes. No complicated setup, just instant access to powerful prompts.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {howItWorks.map((step, index) => (
              <div key={step.title} className="relative">
                <div className="glass rounded-2xl p-8 h-full">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-6">
                    <step.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div className="text-sm text-primary font-medium mb-2">
                    Step {index + 1}
                  </div>
                  <h3 className="text-xl font-semibold text-text-primary mb-3">
                    {step.title}
                  </h3>
                  <p className="text-text-secondary">
                    {step.description}
                  </p>
                </div>
                {index < howItWorks.length - 1 && (
                  <div className="hidden md:block absolute top-1/2 -right-4 w-8 h-px bg-border" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl sm:text-4xl font-bold text-text-primary mb-6">
                Why Choose HaloTechX?
              </h2>
              <p className="text-text-secondary mb-8">
                We&apos;re building the most trusted marketplace for AI prompts. 
                Here&apos;s what sets us apart.
              </p>

              <div className="space-y-6">
                {[
                  {
                    title: 'Expert-Crafted Prompts',
                    description: 'Every prompt is tested and optimized by AI professionals.',
                  },
                  {
                    title: 'Multi-Rail Payments',
                    description: 'Pay with Paynow (ZW), Flutterwave (Africa), or Crypto (Global).',
                  },
                  {
                    title: 'Instant Delivery',
                    description: 'Secure, signed download links delivered immediately after purchase.',
                  },
                  {
                    title: 'Lifetime Access',
                    description: 'Buy once, own forever. Re-download anytime from your dashboard.',
                  },
                ].map((feature) => (
                  <div key={feature.title} className="flex items-start gap-4">
                    <div className="w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle className="w-4 h-4 text-green-400" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-text-primary mb-1">
                        {feature.title}
                      </h4>
                      <p className="text-text-secondary text-sm">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-3xl blur-3xl" />
              <div className="relative glass-strong rounded-3xl p-8">
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-4 bg-surface rounded-xl">
                    <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                      <Zap className="w-5 h-5 text-blue-400" />
                    </div>
                    <div>
                      <div className="font-medium text-text-primary">ChatGPT Business Pack</div>
                      <div className="text-sm text-text-secondary">50+ business prompts</div>
                    </div>
                    <div className="ml-auto text-primary font-semibold">$29.99</div>
                  </div>
                  
                  <div className="flex items-center gap-3 p-4 bg-surface rounded-xl">
                    <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                      <Globe className="w-5 h-5 text-purple-400" />
                    </div>
                    <div>
                      <div className="font-medium text-text-primary">Midjourney Art Styles</div>
                      <div className="text-sm text-text-secondary">100+ art prompts</div>
                    </div>
                    <div className="ml-auto text-primary font-semibold">$39.99</div>
                  </div>
                  
                  <div className="flex items-center gap-3 p-4 bg-surface rounded-xl">
                    <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                      <Shield className="w-5 h-5 text-green-400" />
                    </div>
                    <div>
                      <div className="font-medium text-text-primary">Code Assistant Pro</div>
                      <div className="text-sm text-text-secondary">75+ dev prompts</div>
                    </div>
                    <div className="ml-auto text-primary font-semibold">$34.99</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary/20 to-accent/20 p-12 sm:p-16 text-center">
            <div className="absolute inset-0 bg-surface/80 backdrop-blur-xl" />
            <div className="relative z-10">
              <h2 className="text-3xl sm:text-4xl font-bold text-text-primary mb-4">
                Ready to Transform Your AI Workflow?
              </h2>
              <p className="text-text-secondary max-w-xl mx-auto mb-8">
                Join thousands of professionals who are already using HaloTechX prompts 
                to get better results faster.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link
                  href="/marketplace"
                  className="w-full sm:w-auto px-8 py-4 bg-primary hover:bg-primary-hover text-white font-semibold rounded-xl transition-all"
                >
                  Browse Marketplace
                </Link>
                <Link
                  href="/auth/signup"
                  className="w-full sm:w-auto px-8 py-4 bg-surface-light hover:bg-border text-text-primary font-semibold rounded-xl transition-all border border-border"
                >
                  Create Account
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
