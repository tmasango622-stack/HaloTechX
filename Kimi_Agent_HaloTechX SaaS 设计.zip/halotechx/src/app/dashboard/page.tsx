'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { PromptPack, Transaction, UserDownload } from '@/types';
import { formatPrice, formatDate } from '@/lib/utils';
import { 
  Loader2, 
  Download, 
  Package, 
  CreditCard, 
  Clock,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  FileText
} from 'lucide-react';

interface OwnedPack extends PromptPack {
  transaction_id: string;
  purchased_at: string;
}

export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [ownedPacks, setOwnedPacks] = useState<OwnedPack[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [downloadingPackId, setDownloadingPackId] = useState<string | null>(null);
  const supabase = createClient();

  useEffect(() => {
    const checkAuthAndLoad = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        router.push('/auth/login?redirect=/dashboard');
        return;
      }

      setUser(user);

      // Fetch owned packs (confirmed transactions with pack details)
      const { data: txData } = await supabase
        .from('transactions')
        .select(`
          id,
          pack_id,
          status,
          created_at,
          prompt_packs:pack_id (*)
        `)
        .eq('user_id', user.id)
        .eq('status', 'confirmed');

      if (txData) {
        const packs: OwnedPack[] = txData
          .filter((tx: any) => tx.prompt_packs)
          .map((tx: any) => ({
            ...tx.prompt_packs,
            transaction_id: tx.id,
            purchased_at: tx.created_at,
          }));
        setOwnedPacks(packs);
      }

      // Fetch recent transactions
      const { data: recentTx } = await supabase
        .from('transactions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(10);

      if (recentTx) {
        setTransactions(recentTx);
      }

      setIsLoading(false);
    };

    checkAuthAndLoad();
  }, [router, supabase]);

  const handleDownload = async (packId: string) => {
    setDownloadingPackId(packId);
    
    try {
      const response = await fetch('/api/v1/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pack_id: packId }),
      });

      const data = await response.json();

      if (data.success && data.url) {
        // Trigger download
        const link = document.createElement('a');
        link.href = data.url;
        link.setAttribute('download', '');
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } else {
        alert(data.error || 'Failed to generate download link');
      }
    } catch (error) {
      console.error('Download error:', error);
      alert('Failed to download pack');
    } finally {
      setDownloadingPackId(null);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'confirmed':
        return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-amber-400" />;
      case 'failed':
      case 'timeout':
        return <AlertCircle className="w-4 h-4 text-red-400" />;
      default:
        return <Clock className="w-4 h-4 text-text-muted" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'Confirmed';
      case 'pending':
        return 'Pending';
      case 'failed':
        return 'Failed';
      case 'timeout':
        return 'Timeout';
      case 'refunded':
        return 'Refunded';
      default:
        return status;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  const totalSpent = transactions
    .filter(tx => tx.status === 'confirmed')
    .reduce((sum, tx) => sum + tx.amount, 0);

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-3xl sm:text-4xl font-bold text-text-primary mb-2">
            My Dashboard
          </h1>
          <p className="text-text-secondary">
            Welcome back, {user?.email}
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-12">
          <div className="glass rounded-xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Package className="w-5 h-5 text-primary" />
              </div>
              <span className="text-text-secondary">My Library</span>
            </div>
            <div className="text-3xl font-bold text-text-primary">
              {ownedPacks.length}
            </div>
            <p className="text-text-muted text-sm">prompt packs owned</p>
          </div>

          <div className="glass rounded-xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-green-400" />
              </div>
              <span className="text-text-secondary">Total Spent</span>
            </div>
            <div className="text-3xl font-bold text-text-primary">
              {formatPrice(totalSpent)}
            </div>
            <p className="text-text-muted text-sm">lifetime purchases</p>
          </div>

          <div className="glass rounded-xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
                <Clock className="w-5 h-5 text-amber-400" />
              </div>
              <span className="text-text-secondary">Pending</span>
            </div>
            <div className="text-3xl font-bold text-text-primary">
              {transactions.filter(tx => tx.status === 'pending').length}
            </div>
            <p className="text-text-muted text-sm">active transactions</p>
          </div>
        </div>

        {/* My Library Section */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-text-primary mb-6">
            My Library
          </h2>
          
          {ownedPacks.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {ownedPacks.map((pack) => (
                <div key={pack.id} className="glass rounded-xl p-6">
                  <div className="flex items-start justify-between mb-4">
                    <span className={`px-2 py-1 rounded text-xs font-medium border ${
                      pack.category === 'Business' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' :
                      pack.category === 'Creative' ? 'bg-purple-500/20 text-purple-400 border-purple-500/30' :
                      pack.category === 'Development' ? 'bg-green-500/20 text-green-400 border-green-500/30' :
                      'bg-slate-500/20 text-slate-400 border-slate-500/30'
                    }`}>
                      {pack.category}
                    </span>
                    <span className="text-text-muted text-sm">
                      {formatDate(pack.purchased_at)}
                    </span>
                  </div>

                  <h3 className="font-semibold text-text-primary mb-2">
                    {pack.title}
                  </h3>
                  
                  <p className="text-text-secondary text-sm mb-4 line-clamp-2">
                    {pack.description}
                  </p>

                  <div className="flex items-center gap-4 mb-4 text-sm text-text-muted">
                    <div className="flex items-center gap-1.5">
                      <FileText className="w-4 h-4" />
                      <span>{pack.prompt_count} prompts</span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleDownload(pack.id)}
                    disabled={downloadingPackId === pack.id}
                    className="w-full py-2.5 bg-primary hover:bg-primary-hover disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium rounded-lg transition-all flex items-center justify-center gap-2"
                  >
                    {downloadingPackId === pack.id ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Generating Link...
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4" />
                        Download
                      </>
                    )}
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="glass rounded-xl p-12 text-center">
              <div className="w-16 h-16 rounded-2xl bg-surface-light flex items-center justify-center mx-auto mb-4">
                <Package className="w-8 h-8 text-text-muted" />
              </div>
              <h3 className="text-lg font-semibold text-text-primary mb-2">
                Your library is empty
              </h3>
              <p className="text-text-secondary mb-6">
                Browse our marketplace to find prompt packs that supercharge your workflow.
              </p>
              <a
                href="/marketplace"
                className="inline-flex items-center gap-2 px-6 py-3 bg-primary hover:bg-primary-hover text-white font-medium rounded-lg transition-all"
              >
                Explore Marketplace
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          )}
        </div>

        {/* Recent Transactions */}
        <div>
          <h2 className="text-2xl font-bold text-text-primary mb-6">
            Recent Transactions
          </h2>
          
          {transactions.length > 0 ? (
            <div className="glass rounded-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left px-6 py-4 text-sm font-medium text-text-secondary">Date</th>
                      <th className="text-left px-6 py-4 text-sm font-medium text-text-secondary">Pack</th>
                      <th className="text-left px-6 py-4 text-sm font-medium text-text-secondary">Gateway</th>
                      <th className="text-left px-6 py-4 text-sm font-medium text-text-secondary">Amount</th>
                      <th className="text-left px-6 py-4 text-sm font-medium text-text-secondary">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.map((tx) => (
                      <tr key={tx.id} className="border-b border-border last:border-0 hover:bg-surface-light/50">
                        <td className="px-6 py-4 text-sm text-text-secondary">
                          {formatDate(tx.created_at)}
                        </td>
                        <td className="px-6 py-4 text-sm text-text-primary">
                          {(tx.metadata as any)?.pack_title || 'Unknown Pack'}
                        </td>
                        <td className="px-6 py-4 text-sm text-text-secondary capitalize">
                          {tx.gateway}
                        </td>
                        <td className="px-6 py-4 text-sm text-text-primary">
                          {formatPrice(tx.amount, tx.currency)}
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            {getStatusIcon(tx.status)}
                            <span className={`text-sm ${
                              tx.status === 'confirmed' ? 'text-green-400' :
                              tx.status === 'pending' ? 'text-amber-400' :
                              tx.status === 'failed' || tx.status === 'timeout' ? 'text-red-400' :
                              'text-text-secondary'
                            }`}>
                              {getStatusText(tx.status)}
                            </span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="glass rounded-xl p-8 text-center">
              <p className="text-text-secondary">No transactions yet</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
