'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';
import { PromptPack } from '@/types';
import { formatPrice, getCategoryColor } from '@/lib/utils';
import { 
  Loader2, 
  ArrowLeft, 
  FileText, 
  Download, 
  CheckCircle, 
  Sparkles,
  Shield,
  Clock,
  Zap
} from 'lucide-react';

export default function ProductPage() {
  const params = useParams();
  const slug = params.slug as string;
  const [pack, setPack] = useState<PromptPack | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isPurchasing, setIsPurchasing] = useState(false);
  const supabase = createClient();

  useEffect(() => {
    const fetchPack = async () => {
      const { data, error } = await supabase
        .from('prompt_packs')
        .select('*')
        .eq('slug', slug)
        .eq('is_published', true)
        .single();

      if (error) {
        console.error('Error fetching pack:', error);
      } else {
        setPack(data);
      }
      setIsLoading(false);
    };

    const checkAuth = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      setIsAuthenticated(!!user);
    };

    fetchPack();
    checkAuth();
  }, [slug, supabase]);

  const handlePurchase = async () => {
    if (!isAuthenticated) {
      window.location.href = `/auth/login?redirect=/product/${slug}`;
      return;
    }

    setIsPurchasing(true);
    
    try {
      const response = await fetch('/api/v1/initiate-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pack_id: pack?.id,
          gateway: 'paynow', // Default gateway, could be selectable
        }),
      });

      const data = await response.json();

      if (data.success && data.gateway_url) {
        window.location.href = data.gateway_url;
      } else {
        alert(data.error || 'Failed to initiate payment');
        setIsPurchasing(false);
      }
    } catch (error) {
      console.error('Purchase error:', error);
      alert('Failed to initiate purchase');
      setIsPurchasing(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (!pack) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4">
        <h1 className="text-2xl font-bold text-text-primary mb-4">Pack Not Found</h1>
        <p className="text-text-secondary mb-6">The prompt pack you&apos;re looking for doesn&apos;t exist.</p>
        <Link href="/marketplace" className="btn-primary">
          Browse Marketplace
        </Link>
      </div>
    );
  }

  const features = [
    { icon: FileText, label: `${pack.prompt_count} Premium Prompts` },
    { icon: Download, label: 'Instant Download' },
    { icon: Shield, label: 'Lifetime Access' },
    { icon: Clock, label: 'Regular Updates' },
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Link */}
        <Link 
          href="/marketplace" 
          className="inline-flex items-center gap-2 text-text-secondary hover:text-text-primary transition-colors mb-8"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Marketplace
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Left Column - Info */}
          <div>
            {/* Category Badge */}
            <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium border mb-4 ${getCategoryColor(pack.category)}`}>
              {pack.category}
            </span>

            {/* Title */}
            <h1 className="text-3xl sm:text-4xl font-bold text-text-primary mb-4">
              {pack.title}
            </h1>

            {/* Description */}
            <p className="text-text-secondary text-lg mb-8 leading-relaxed">
              {pack.description}
            </p>

            {/* Features */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              {features.map((feature) => (
                <div key={feature.label} className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <feature.icon className="w-5 h-5 text-primary" />
                  </div>
                  <span className="text-text-secondary text-sm">{feature.label}</span>
                </div>
              ))}
            </div>

            {/* Compatibility */}
            <div className="mb-8">
              <h3 className="text-sm font-semibold text-text-primary mb-3">
                Compatible With
              </h3>
              <div className="flex flex-wrap gap-2">
                {pack.compatibility_tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1.5 bg-surface-light border border-border rounded-lg text-sm text-text-secondary"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Preview Section */}
            {pack.preview_text && (
              <div className="glass rounded-2xl p-6 mb-8">
                <div className="flex items-center gap-2 mb-4">
                  <Sparkles className="w-5 h-5 text-primary" />
                  <h3 className="font-semibold text-text-primary">Prompt Preview</h3>
                </div>
                <blockquote className="text-text-secondary italic border-l-2 border-primary pl-4">
                  &ldquo;{pack.preview_text}&rdquo;
                </blockquote>
              </div>
            )}

            {/* Stats */}
            <div className="flex items-center gap-8 text-sm text-text-muted">
              <div>
                <span className="text-text-primary font-semibold">{pack.download_count.toLocaleString()}</span>
                {' '}downloads
              </div>
              <div>
                Added {new Date(pack.created_at).toLocaleDateString()}
              </div>
            </div>
          </div>

          {/* Right Column - Purchase Card */}
          <div className="lg:sticky lg:top-24 h-fit">
            <div className="glass-strong rounded-2xl p-8">
              {/* Price */}
              <div className="text-center mb-8">
                <div className="text-5xl font-bold text-text-primary mb-2">
                  {formatPrice(pack.price_usd)}
                </div>
                <p className="text-text-secondary text-sm">One-time purchase</p>
              </div>

              {/* CTA Button */}
              <button
                onClick={handlePurchase}
                disabled={isPurchasing}
                className="w-full py-4 bg-primary hover:bg-primary-hover disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold rounded-xl transition-all flex items-center justify-center gap-2 mb-6"
              >
                {isPurchasing ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Zap className="w-5 h-5" />
                    {isAuthenticated ? 'Buy Now' : 'Sign In to Purchase'}
                  </>
                )}
              </button>

              {/* Payment Methods */}
              <div className="text-center mb-6">
                <p className="text-text-muted text-sm mb-3">Secure payment via</p>
                <div className="flex items-center justify-center gap-3">
                  <span className="px-3 py-1 bg-surface-light rounded text-xs text-text-secondary">Paynow</span>
                  <span className="px-3 py-1 bg-surface-light rounded text-xs text-text-secondary">Flutterwave</span>
                  <span className="px-3 py-1 bg-surface-light rounded text-xs text-text-secondary">Crypto</span>
                </div>
              </div>

              {/* Guarantees */}
              <div className="space-y-3 pt-6 border-t border-border">
                {[
                  'Instant delivery after payment',
                  '30-day money-back guarantee',
                  'Lifetime access & updates',
                ].map((item) => (
                  <div key={item} className="flex items-center gap-2 text-sm text-text-secondary">
                    <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
                    {item}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
