import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';

const PAYNOW_POLL_CONFIG = {
  timeoutMinutes: parseInt(process.env.PAYNOW_POLL_TIMEOUT_MINUTES || '5'),
  intervalSeconds: parseInt(process.env.PAYNOW_POLL_INTERVAL_SECONDS || '10'),
};

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { transaction_id } = body;

    if (!transaction_id) {
      return NextResponse.json(
        { error: 'Missing transaction_id' },
        { status: 400 }
      );
    }

    const supabase = createAdminClient();

    // Fetch transaction
    const { data: transaction, error: txError } = await supabase
      .from('transactions')
      .select('*')
      .eq('id', transaction_id)
      .eq('gateway', 'paynow')
      .single();

    if (txError || !transaction) {
      return NextResponse.json(
        { error: 'Transaction not found' },
        { status: 404 }
      );
    }

    // Check if already confirmed or failed
    if (transaction.status === 'confirmed') {
      return NextResponse.json({
        status: 'confirmed',
        transaction_id: transaction.id,
        message: 'Payment confirmed',
      });
    }

    if (transaction.status === 'failed' || transaction.status === 'timeout') {
      return NextResponse.json({
        status: transaction.status,
        transaction_id: transaction.id,
        message: `Payment ${transaction.status}`,
      });
    }

    // Increment poll count
    const newPollCount = (transaction.poll_count || 0) + 1;
    
    // Check for timeout
    const createdAt = new Date(transaction.created_at);
    const now = new Date();
    const elapsedMinutes = (now.getTime() - createdAt.getTime()) / (1000 * 60);

    if (elapsedMinutes > PAYNOW_POLL_CONFIG.timeoutMinutes) {
      // Update to timeout status
      const { error: updateError } = await supabase
        .from('transactions')
        .update({
          status: 'timeout',
          poll_count: newPollCount,
          last_polled_at: now.toISOString(),
          metadata: {
            ...transaction.metadata,
            timeout_at: now.toISOString(),
            support_link: `${process.env.NEXT_PUBLIC_SITE_URL}/support?tx=${transaction.id}`,
          },
          updated_at: now.toISOString(),
        })
        .eq('id', transaction.id);

      if (updateError) {
        console.error('Error updating timeout status:', updateError);
      }

      return NextResponse.json({
        status: 'timeout',
        transaction_id: transaction.id,
        message: 'Payment timed out. Please contact support.',
        support_url: `${process.env.NEXT_PUBLIC_SITE_URL}/support?tx=${transaction.id}`,
      });
    }

    // Poll Paynow API for status
    const paynowStatus = await pollPaynowAPI(transaction.gateway_transaction_id);

    // Update poll count and last polled time
    await supabase
      .from('transactions')
      .update({
        poll_count: newPollCount,
        last_polled_at: now.toISOString(),
      })
      .eq('id', transaction.id);

    // Handle Paynow response
    if (paynowStatus.status === 'paid' || paynowStatus.status === 'Paid') {
      // Payment confirmed
      const { error: updateError } = await supabase
        .from('transactions')
        .update({
          status: 'confirmed',
          metadata: {
            ...transaction.metadata,
            paynow_reference: paynowStatus.paynowreference,
            confirmed_at: now.toISOString(),
            poll_count_at_confirmation: newPollCount,
          },
          updated_at: now.toISOString(),
        })
        .eq('id', transaction.id);

      if (updateError) {
        console.error('Error confirming payment:', updateError);
      }

      return NextResponse.json({
        status: 'confirmed',
        transaction_id: transaction.id,
        message: 'Payment confirmed successfully',
      });
    }

    if (paynowStatus.status === 'cancelled' || paynowStatus.status === 'Cancelled') {
      // Payment cancelled
      await supabase
        .from('transactions')
        .update({
          status: 'failed',
          metadata: {
            ...transaction.metadata,
            cancelled_at: now.toISOString(),
          },
          updated_at: now.toISOString(),
        })
        .eq('id', transaction.id);

      return NextResponse.json({
        status: 'failed',
        transaction_id: transaction.id,
        message: 'Payment was cancelled',
      });
    }

    // Still pending
    return NextResponse.json({
      status: 'pending',
      transaction_id: transaction.id,
      poll_count: newPollCount,
      elapsed_minutes: Math.round(elapsedMinutes * 10) / 10,
      timeout_after_minutes: PAYNOW_POLL_CONFIG.timeoutMinutes,
      message: 'Payment pending. Please complete payment on Paynow.',
    });

  } catch (error) {
    console.error('Error in paynow-poll:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

async function pollPaynowAPI(gatewayTransactionId: string | null): Promise<any> {
  if (!gatewayTransactionId) {
    return { status: 'unknown' };
  }

  try {
    const integrationId = process.env.PAYNOW_INTEGRATION_ID;
    const integrationKey = process.env.PAYNOW_INTEGRATION_KEY;

    if (!integrationId || !integrationKey) {
      console.error('Paynow credentials not configured');
      return { status: 'unknown' };
    }

    // Construct status check URL
    const statusUrl = `https://www.paynow.co.zw/interface/statusupdate?integration_id=${integrationId}&integration_key=${integrationKey}&reference=${gatewayTransactionId}`;

    const response = await fetch(statusUrl, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
      },
    });

    if (!response.ok) {
      console.error('Paynow API error:', response.status);
      return { status: 'unknown' };
    }

    const data = await response.json();
    return data;

  } catch (error) {
    console.error('Error polling Paynow:', error);
    return { status: 'unknown' };
  }
}

// GET endpoint for checking poll configuration
export async function GET() {
  return NextResponse.json({
    config: {
      timeout_minutes: PAYNOW_POLL_CONFIG.timeoutMinutes,
      interval_seconds: PAYNOW_POLL_CONFIG.intervalSeconds,
    },
    message: 'Paynow polling endpoint active',
  });
}
