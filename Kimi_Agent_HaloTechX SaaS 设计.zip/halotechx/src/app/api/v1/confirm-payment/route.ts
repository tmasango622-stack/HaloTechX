import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { PaymentGateway } from '@/types';
import crypto from 'crypto';

// Gateway configuration
const GATEWAY_CONFIG = {
  paynow: {
    secret: process.env.PAYNOW_INTEGRATION_KEY,
    verifySignature: verifyPaynowSignature,
  },
  flutterwave: {
    secret: process.env.FLUTTERWAVE_SECRET_KEY,
    verifySignature: verifyFlutterwaveSignature,
  },
  nowpayments: {
    secret: process.env.NOWPAYMENTS_IPN_SECRET,
    verifySignature: verifyNowPaymentsSignature,
  },
};

function verifyPaynowSignature(payload: string, signature: string, secret: string): boolean {
  const expected = crypto
    .createHash('sha512')
    .update(payload + secret)
    .digest('hex')
    .toUpperCase();
  return signature.toUpperCase() === expected;
}

function verifyFlutterwaveSignature(payload: string, signature: string, secret: string): boolean {
  const expected = crypto
    .createHmac('sha256', secret)
    .update(payload)
    .digest('hex');
  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expected)
  );
}

function verifyNowPaymentsSignature(payload: string, signature: string, secret: string): boolean {
  const expected = crypto
    .createHmac('sha512', secret)
    .update(payload)
    .digest('hex');
  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expected)
  );
}

export async function POST(request: NextRequest) {
  try {
    // Detect gateway from header
    const gatewayHeader = request.headers.get('X-Gateway') as PaymentGateway | null;
    
    if (!gatewayHeader || !['paynow', 'flutterwave', 'nowpayments'].includes(gatewayHeader)) {
      return NextResponse.json(
        { error: 'Invalid or missing X-Gateway header' },
        { status: 400 }
      );
    }

    const gateway = gatewayHeader as PaymentGateway;
    const config = GATEWAY_CONFIG[gateway];

    if (!config.secret) {
      return NextResponse.json(
        { error: `Gateway ${gateway} is not configured` },
        { status: 500 }
      );
    }

    // Get signature from appropriate header
    const signatureHeader = gateway === 'paynow' ? 'X-Paynow-Signature' :
                           gateway === 'flutterwave' ? 'verif-hash' :
                           'x-nowpayments-sig';
    
    const signature = request.headers.get(signatureHeader) || 
                     request.headers.get(signatureHeader.toLowerCase());

    if (!signature) {
      return NextResponse.json(
        { error: `Missing ${signatureHeader} header` },
        { status: 401 }
      );
    }

    // Parse payload
    const payload = await request.text();
    const body = JSON.parse(payload);

    // Verify signature
    const isValid = config.verifySignature(payload, signature, config.secret);
    
    if (!isValid) {
      console.error(`Invalid ${gateway} signature received`);
      return NextResponse.json(
        { error: 'Invalid signature' },
        { status: 401 }
      );
    }

    const supabase = createAdminClient();

    // Process based on gateway
    switch (gateway) {
      case 'paynow':
        return await processPaynowPayment(body, supabase);
      case 'flutterwave':
        return await processFlutterwavePayment(body, supabase);
      case 'nowpayments':
        return await processNowPaymentsPayment(body, supabase);
      default:
        return NextResponse.json(
          { error: 'Unsupported gateway' },
          { status: 400 }
        );
    }

  } catch (error) {
    console.error('Error in confirm-payment:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

async function processPaynowPayment(body: any, supabase: any) {
  const { reference, paynowreference, status, amount, hash } = body;

  // Find transaction by gateway transaction ID
  const { data: transaction, error: txError } = await supabase
    .from('transactions')
    .select('*')
    .eq('gateway_transaction_id', reference)
    .single();

  if (txError || !transaction) {
    console.error('Transaction not found:', reference);
    return NextResponse.json(
      { error: 'Transaction not found' },
      { status: 404 }
    );
  }

  // Update transaction status
  const newStatus = status === 'Paid' || status === 'paid' ? 'confirmed' : 
                    status === 'Cancelled' || status === 'cancelled' ? 'failed' : 
                    'pending';

  const { error: updateError } = await supabase
    .from('transactions')
    .update({
      status: newStatus,
      metadata: {
        ...transaction.metadata,
        paynow_reference: paynowreference,
        confirmed_at: new Date().toISOString(),
        raw_response: body,
      },
      updated_at: new Date().toISOString(),
    })
    .eq('id', transaction.id);

  if (updateError) {
    console.error('Error updating transaction:', updateError);
    return NextResponse.json(
      { error: 'Failed to update transaction' },
      { status: 500 }
    );
  }

  return NextResponse.json({
    success: true,
    transaction_id: transaction.id,
    status: newStatus,
    message: `Payment ${newStatus} successfully`,
  });
}

async function processFlutterwavePayment(body: any, supabase: any) {
  const { data } = body;
  const txRef = data?.tx_ref;
  const status = data?.status;

  if (!txRef) {
    return NextResponse.json(
      { error: 'Missing tx_ref in payload' },
      { status: 400 }
    );
  }

  // Find transaction
  const { data: transaction, error: txError } = await supabase
    .from('transactions')
    .select('*')
    .eq('gateway_transaction_id', txRef)
    .single();

  if (txError || !transaction) {
    console.error('Transaction not found:', txRef);
    return NextResponse.json(
      { error: 'Transaction not found' },
      { status: 404 }
    );
  }

  // Update transaction
  const newStatus = status === 'successful' ? 'confirmed' :
                    status === 'failed' || status === 'cancelled' ? 'failed' :
                    'pending';

  const { error: updateError } = await supabase
    .from('transactions')
    .update({
      status: newStatus,
      metadata: {
        ...transaction.metadata,
        flutterwave_transaction_id: data.id,
        confirmed_at: new Date().toISOString(),
        raw_response: body,
      },
      updated_at: new Date().toISOString(),
    })
    .eq('id', transaction.id);

  if (updateError) {
    console.error('Error updating transaction:', updateError);
    return NextResponse.json(
      { error: 'Failed to update transaction' },
      { status: 500 }
    );
  }

  return NextResponse.json({
    success: true,
    transaction_id: transaction.id,
    status: newStatus,
    message: `Payment ${newStatus} successfully`,
  });
}

async function processNowPaymentsPayment(body: any, supabase: any) {
  const { order_id, payment_status, pay_address } = body;

  if (!order_id) {
    return NextResponse.json(
      { error: 'Missing order_id in payload' },
      { status: 400 }
    );
  }

  // Find transaction
  const { data: transaction, error: txError } = await supabase
    .from('transactions')
    .select('*')
    .eq('gateway_transaction_id', order_id)
    .single();

  if (txError || !transaction) {
    console.error('Transaction not found:', order_id);
    return NextResponse.json(
      { error: 'Transaction not found' },
      { status: 404 }
    );
  }

  // Update transaction
  const newStatus = payment_status === 'finished' || payment_status === 'confirmed' ? 'confirmed' :
                    payment_status === 'failed' || payment_status === 'expired' ? 'failed' :
                    'pending';

  const { error: updateError } = await supabase
    .from('transactions')
    .update({
      status: newStatus,
      metadata: {
        ...transaction.metadata,
        crypto_address: pay_address,
        confirmed_at: new Date().toISOString(),
        raw_response: body,
      },
      updated_at: new Date().toISOString(),
    })
    .eq('id', transaction.id);

  if (updateError) {
    console.error('Error updating transaction:', updateError);
    return NextResponse.json(
      { error: 'Failed to update transaction' },
      { status: 500 }
    );
  }

  return NextResponse.json({
    success: true,
    transaction_id: transaction.id,
    status: newStatus,
    message: `Payment ${newStatus} successfully`,
  });
}
