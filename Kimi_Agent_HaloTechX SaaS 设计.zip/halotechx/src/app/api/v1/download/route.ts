import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';

const SIGNED_URL_EXPIRY_MINUTES = parseInt(process.env.SIGNED_URL_EXPIRY_MINUTES || '15');

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient();
    
    // Verify user is authenticated
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    
    if (authError || !user) {
      return NextResponse.json(
        { error: 'Unauthorized. Please sign in to download.' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { pack_id } = body;

    if (!pack_id) {
      return NextResponse.json(
        { error: 'Missing pack_id' },
        { status: 400 }
      );
    }

    const adminClient = createAdminClient();

    // Verify user owns this pack (has confirmed transaction)
    const { data: transaction, error: txError } = await adminClient
      .from('transactions')
      .select('*')
      .eq('user_id', user.id)
      .eq('pack_id', pack_id)
      .eq('status', 'confirmed')
      .maybeSingle();

    if (txError || !transaction) {
      return NextResponse.json(
        { error: 'You do not have access to this pack. Please purchase it first.' },
        { status: 403 }
      );
    }

    // Fetch pack file path
    const { data: pack, error: packError } = await adminClient
      .from('prompt_packs')
      .select('file_path, title')
      .eq('id', pack_id)
      .single();

    if (packError || !pack) {
      return NextResponse.json(
        { error: 'Pack not found' },
        { status: 404 }
      );
    }

    // Generate signed URL
    const { data: signedUrlData, error: signedUrlError } = await adminClient
      .storage
      .from('prompt-packs')
      .createSignedUrl(pack.file_path, SIGNED_URL_EXPIRY_MINUTES * 60);

    if (signedUrlError || !signedUrlData) {
      console.error('Error generating signed URL:', signedUrlError);
      return NextResponse.json(
        { error: 'Failed to generate download link' },
        { status: 500 }
      );
    }

    // Log download for analytics and security
    const ipAddress = request.headers.get('x-forwarded-for') || 
                     request.headers.get('x-real-ip') || 
                     'unknown';
    const userAgent = request.headers.get('user-agent') || 'unknown';

    await adminClient
      .from('user_downloads')
      .insert({
        user_id: user.id,
        pack_id: pack_id,
        transaction_id: transaction.id,
        ip_address: ipAddress,
        user_agent: userAgent,
      });

    // Increment download count on pack
    await adminClient.rpc('increment_download_count', { pack_id });

    // Calculate expiry time
    const expiresAt = new Date();
    expiresAt.setMinutes(expiresAt.getMinutes() + SIGNED_URL_EXPIRY_MINUTES);

    return NextResponse.json({
      success: true,
      url: signedUrlData.signedUrl,
      expires_at: expiresAt.toISOString(),
      pack_title: pack.title,
      message: `Download link valid for ${SIGNED_URL_EXPIRY_MINUTES} minutes`,
    });

  } catch (error) {
    console.error('Error in download endpoint:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// GET endpoint to check download eligibility
export async function GET(request: NextRequest) {
  try {
    const supabase = createClient();
    
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    
    if (authError || !user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const packId = searchParams.get('pack_id');

    if (!packId) {
      return NextResponse.json(
        { error: 'Missing pack_id parameter' },
        { status: 400 }
      );
    }

    const adminClient = createAdminClient();

    // Check ownership
    const { data: transaction, error: txError } = await adminClient
      .from('transactions')
      .select('id, status, created_at')
      .eq('user_id', user.id)
      .eq('pack_id', packId)
      .eq('status', 'confirmed')
      .maybeSingle();

    // Get download history
    const { data: downloads, error: dlError } = await adminClient
      .from('user_downloads')
      .select('downloaded_at')
      .eq('user_id', user.id)
      .eq('pack_id', packId)
      .order('downloaded_at', { ascending: false })
      .limit(5);

    return NextResponse.json({
      has_access: !!transaction,
      transaction: transaction || null,
      download_history: downloads || [],
      can_download: !!transaction,
    });

  } catch (error) {
    console.error('Error checking download eligibility:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
