import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { PaymentGateway } from '@/types';
import crypto from 'crypto';

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient();
    
    // Verify user is authenticated
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    
    if (authError || !user) {
      return NextResponse.json(
        { error: 'Unauthorized. Please sign in to make a purchase.' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { pack_id, gateway, return_url } = body;

    // Validate inputs
    if (!pack_id || !gateway) {
      return NextResponse.json(
        { error: 'Missing required fields: pack_id, gateway' },
        { status: 400 }
      );
    }

    if (!['paynow', 'flutterwave', 'nowpayments'].includes(gateway)) {
      return NextResponse.json(
        { error: 'Invalid gateway. Must be: paynow, flutterwave, or nowpayments' },
        { status: 400 }
      );
    }

    const adminClient = createAdminClient();

    // Fetch pack details
    const { data: pack, error: packError } = await adminClient
      .from('prompt_packs')
      .select('*')
      .eq('id', pack_id)
      .eq('is_published', true)
      .single();

    if (packError || !pack) {
      return NextResponse.json(
        { error: 'Pack not found or unavailable' },
        { status: 404 }
      );
    }

    // Check if user already owns this pack
    const { data: existingTx, error: existingTxError } = await adminClient
      .from('transactions')
      .select('*')
      .eq('user_id', user.id)
      .eq('pack_id', pack_id)
      .eq('status', 'confirmed')
      .maybeSingle();

    if (existingTx) {
      return NextResponse.json(
        { error: 'You already own this pack', redirect_to: '/dashboard' },
        { status: 409 }
      );
    }

    // Create transaction record
    const gatewayTxId = generateGatewayTransactionId(gateway);
    const { data: transaction, error: txError } = await adminClient
      .from('transactions')
      .insert({
        user_id: user.id,
        pack_id: pack_id,
        gateway: gateway as PaymentGateway,
        status: 'pending',
        amount: pack.price_usd,
        currency: 'USD',
        gateway_transaction_id: gatewayTxId,
        metadata: {
          pack_title: pack.title,
          initiated_at: new Date().toISOString(),
          return_url: return_url || `${process.env.NEXT_PUBLIC_SITE_URL}/dashboard`,
        },
      })
      .select()
      .single();

    if (txError) {
      console.error('Error creating transaction:', txError);
      return NextResponse.json(
        { error: 'Failed to create transaction' },
        { status: 500 }
      );
    }

    // Initialize payment with selected gateway
    let paymentData;
    switch (gateway) {
      case 'paynow':
        paymentData = await initPaynowPayment(pack, transaction, user);
        break;
      case 'flutterwave':
        paymentData = await initFlutterwavePayment(pack, transaction, user);
        break;
      case 'nowpayments':
        paymentData = await initNowPaymentsPayment(pack, transaction, user);
        break;
    }

    return NextResponse.json({
      success: true,
      transaction_id: transaction.id,
      gateway,
      ...paymentData,
    });

  } catch (error) {
    console.error('Error in initiate-payment:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

function generateGatewayTransactionId(gateway: PaymentGateway): string {
  const prefix = gateway === 'paynow' ? 'PN' : gateway === 'flutterwave' ? 'FW' : 'NP';
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = crypto.randomBytes(4).toString('hex').toUpperCase();
  return `${prefix}-${timestamp}-${random}`;
}

async function initPaynowPayment(pack: any, transaction: any, user: any) {
  const integrationId = process.env.PAYNOW_INTEGRATION_ID;
  const integrationKey = process.env.PAYNOW_INTEGRATION_KEY;
  const resultUrl = process.env.PAYNOW_RESULT_URL;
  const returnUrl = process.env.PAYNOW_RETURN_URL;

  if (!integrationId || !integrationKey) {
    throw new Error('Paynow not configured');
  }

  // Build Paynow init request
  const paynowData = {
    id: integrationId,
    reference: transaction.gateway_transaction_id,
    amount: pack.price_usd.toFixed(2),
    info: `HaloTechX - ${pack.title}`,
    status: 'Message',
    returnurl: returnUrl,
    resulturl: resultUrl,
    email: user.email,
  };

  // Generate hash
  const hashString = Object.values(paynowData).join('') + integrationKey;
  const hash = crypto.createHash('sha512').update(hashString).digest('hex').toUpperCase();

  try {
    const response = await fetch('https://www.paynow.co.zw/interface/initiatetransaction', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        ...paynowData,
        hash,
      }),
    });

    const responseText = await response.text();
    
    // Parse Paynow response (format: "status=...&browserurl=...&pollurl=...&error=...")
    const params = new URLSearchParams(responseText);
    const status = params.get('status');

    if (status === 'ok' || status === 'Ok' || status === 'OK') {
      return {
        gateway_url: params.get('browserurl'),
        poll_url: params.get('pollurl'),
        hash: params.get('hash'),
      };
    } else {
      const error = params.get('error') || 'Unknown Paynow error';
      throw new Error(error);
    }

  } catch (error) {
    console.error('Paynow init error:', error);
    throw new Error('Failed to initialize Paynow payment');
  }
}

async function initFlutterwavePayment(pack: any, transaction: any, user: any) {
  const publicKey = process.env.FLUTTERWAVE_PUBLIC_KEY;
  const secretKey = process.env.FLUTTERWAVE_SECRET_KEY;
  const encryptionKey = process.env.FLUTTERWAVE_ENCRYPTION_KEY;

  if (!publicKey || !secretKey) {
    throw new Error('Flutterwave not configured');
  }

  const payload = {
    tx_ref: transaction.gateway_transaction_id,
    amount: pack.price_usd,
    currency: 'USD',
    redirect_url: `${process.env.NEXT_PUBLIC_SITE_URL}/api/v1/confirm-payment`,
    meta: {
      transaction_id: transaction.id,
      pack_id: pack.id,
    },
    customer: {
      email: user.email,
      name: user.user_metadata?.full_name || user.email,
    },
    customizations: {
      title: 'HaloTechX',
      description: pack.title,
      logo: `${process.env.NEXT_PUBLIC_SITE_URL}/logo.png`,
    },
  };

  try {
    const response = await fetch('https://api.flutterwave.com/v3/payments', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${secretKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json();

    if (data.status === 'success') {
      return {
        gateway_url: data.data.link,
        public_key: publicKey,
        payment_data: payload,
      };
    } else {
      throw new Error(data.message || 'Flutterwave payment init failed');
    }

  } catch (error) {
    console.error('Flutterwave init error:', error);
    throw new Error('Failed to initialize Flutterwave payment');
  }
}

async function initNowPaymentsPayment(pack: any, transaction: any, user: any) {
  const apiKey = process.env.NOWPAYMENTS_API_KEY;

  if (!apiKey) {
    throw new Error('NOWPayments not configured');
  }

  const payload = {
    price_amount: pack.price_usd,
    price_currency: 'usd',
    order_id: transaction.gateway_transaction_id,
    order_description: `HaloTechX - ${pack.title}`,
    ipn_callback_url: `${process.env.NEXT_PUBLIC_SITE_URL}/api/v1/confirm-payment`,
    success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/dashboard?payment=success`,
    cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL}/marketplace`,
  };

  try {
    const response = await fetch('https://api.nowpayments.io/v1/payment', {
      method: 'POST',
      headers: {
        'x-api-key': apiKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json();

    if (data.payment_id) {
      return {
        gateway_url: data.invoice_url,
        payment_id: data.payment_id,
        pay_address: data.pay_address,
        payment_data: {
          amount: data.pay_amount,
          currency: data.pay_currency,
          address: data.pay_address,
        },
      };
    } else {
      throw new Error(data.message || 'NOWPayments init failed');
    }

  } catch (error) {
    console.error('NOWPayments init error:', error);
    throw new Error('Failed to initialize crypto payment');
  }
}
