import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { generateSlug, normalizeTitle, generateSEOFields } from '@/lib/utils';
import { z } from 'zod';

const ZAPIER_SECRET = process.env.ZAPIER_WEBHOOK_SECRET;

const packSchema = z.object({
  title: z.string().min(1).max(200),
  description: z.string().min(10).max(5000),
  category: z.string().min(1).max(100),
  prompt_count: z.number().int().min(1).max(10000),
  preview_text: z.string().optional(),
  price_usd: z.number().min(0).max(10000),
  compatibility_tags: z.array(z.string()).optional(),
  file_path: z.string().min(1),
  file_size_bytes: z.number().optional(),
  seo_title: z.string().optional(),
  seo_description: z.string().max(160).optional(),
  is_featured: z.boolean().optional(),
});

export async function POST(request: NextRequest) {
  try {
    // Verify Zapier secret header
    const zapierSecret = request.headers.get('X-Zapier-Secret');
    
    if (!ZAPIER_SECRET || zapierSecret !== ZAPIER_SECRET) {
      return NextResponse.json(
        { error: 'Unauthorized: Invalid or missing Zapier secret' },
        { status: 401 }
      );
    }

    // Parse and validate request body
    const body = await request.json();
    const validation = packSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        { error: 'Invalid payload', details: validation.error.issues },
        { status: 400 }
      );
    }

    const packData = validation.data;
    const supabase = createAdminClient();

    // Normalize title for duplicate detection
    const normalizedTitle = normalizeTitle(packData.title);

    // Check if pack with similar title already exists
    const { data: existingPacks, error: searchError } = await supabase
      .from('prompt_packs')
      .select('id, slug, title')
      .ilike('title', `%${normalizedTitle.replace(/\s+/g, '%')}%`);

    if (searchError) {
      console.error('Error searching for existing packs:', searchError);
      return NextResponse.json(
        { error: 'Database error while searching for existing packs' },
        { status: 500 }
      );
    }

    // Find exact match by normalized title
    const exactMatch = existingPacks?.find(
      (pack) => normalizeTitle(pack.title) === normalizedTitle
    );

    // Generate SEO fields if not provided
    const seoFields = packData.seo_title && packData.seo_description
      ? { seo_title: packData.seo_title, seo_description: packData.seo_description }
      : generateSEOFields(packData.title, packData.description);

    if (exactMatch) {
      // UPSERT: Update existing pack but preserve slug for SEO
      const { data: updatedPack, error: updateError } = await supabase
        .from('prompt_packs')
        .update({
          title: packData.title,
          description: packData.description,
          category: packData.category,
          prompt_count: packData.prompt_count,
          preview_text: packData.preview_text || null,
          price_usd: packData.price_usd,
          compatibility_tags: packData.compatibility_tags || [],
          file_path: packData.file_path,
          file_size_bytes: packData.file_size_bytes || null,
          is_featured: packData.is_featured || false,
          ...seoFields,
          updated_at: new Date().toISOString(),
        })
        .eq('id', exactMatch.id)
        .select()
        .single();

      if (updateError) {
        console.error('Error updating pack:', updateError);
        return NextResponse.json(
          { error: 'Failed to update prompt pack' },
          { status: 500 }
        );
      }

      return NextResponse.json({
        success: true,
        action: 'updated',
        pack: updatedPack,
        message: 'Prompt pack updated successfully (slug preserved for SEO)',
      });
    }

    // INSERT: Create new pack with generated slug
    const slug = generateSlug(packData.title);

    const { data: newPack, error: insertError } = await supabase
      .from('prompt_packs')
      .insert({
        title: packData.title,
        slug,
        description: packData.description,
        category: packData.category,
        prompt_count: packData.prompt_count,
        preview_text: packData.preview_text || null,
        price_usd: packData.price_usd,
        compatibility_tags: packData.compatibility_tags || [],
        file_path: packData.file_path,
        file_size_bytes: packData.file_size_bytes || null,
        is_featured: packData.is_featured || false,
        is_published: true,
        ...seoFields,
      })
      .select()
      .single();

    if (insertError) {
      console.error('Error inserting pack:', insertError);
      return NextResponse.json(
        { error: 'Failed to create prompt pack' },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      action: 'created',
      pack: newPack,
      message: 'Prompt pack created successfully',
    }, { status: 201 });

  } catch (error) {
    console.error('Unexpected error in ingest-prompt-pack:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Health check endpoint
export async function GET() {
  return NextResponse.json({
    status: 'ok',
    service: 'HaloTechX Prompt Pack Ingestion API',
    version: '1.0.0',
  });
}
