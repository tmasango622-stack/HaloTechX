import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { Toaster } from '@/components/ui/Toaster';

const inter = Inter({ 
  subsets: ['latin'],
  variable: '--font-inter',
});

export const metadata: Metadata = {
  title: 'HaloTechX - Premium AI Prompt Packs Marketplace',
  description: 'Discover and purchase professionally crafted AI prompt packs for ChatGPT, Midjourney, Claude, and more. Supercharge your AI workflow today.',
  keywords: ['AI prompts', 'ChatGPT prompts', 'Midjourney prompts', 'AI marketplace', 'prompt engineering'],
  authors: [{ name: 'HaloTechX' }],
  openGraph: {
    title: 'HaloTechX - Premium AI Prompt Packs',
    description: 'Discover professionally crafted AI prompt packs for every use case.',
    type: 'website',
    url: 'https://halotechx.com',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.variable} font-sans antialiased`}>
        <div className="min-h-screen flex flex-col">
          <Navbar />
          <main className="flex-1">
            {children}
          </main>
          <Footer />
        </div>
        <Toaster />
      </body>
    </html>
  );
}
