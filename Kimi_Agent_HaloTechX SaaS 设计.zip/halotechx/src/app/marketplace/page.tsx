'use client';

import { useState, useEffect, useCallback } from 'react';
import { createClient } from '@/lib/supabase/client';
import { ProductCard } from '@/components/marketplace/ProductCard';
import { FilterBar } from '@/components/marketplace/FilterBar';
import { PromptPack, FilterOptions } from '@/types';
import { Loader2, Package } from 'lucide-react';

const CATEGORIES = ['Business', 'Creative', 'Development', 'Marketing', 'Data Science', 'Writing'];
const COMPATIBILITY_OPTIONS = ['ChatGPT', 'GPT-4', 'Claude', 'Midjourney', 'DALL-E', 'Stable Diffusion', 'GitHub Copilot'];

export default function MarketplacePage() {
  const [packs, setPacks] = useState<PromptPack[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filters, setFilters] = useState<FilterOptions>({ sortBy: 'newest' });
  const supabase = createClient();

  const fetchPacks = useCallback(async () => {
    setIsLoading(true);
    
    let query = supabase
      .from('prompt_packs')
      .select('*')
      .eq('is_published', true);

    // Apply filters
    if (filters.category) {
      query = query.eq('category', filters.category);
    }

    if (filters.minPrice !== undefined) {
      query = query.gte('price_usd', filters.minPrice);
    }

    if (filters.maxPrice !== undefined) {
      query = query.lte('price_usd', filters.maxPrice);
    }

    if (filters.search) {
      query = query.or(`title.ilike.%${filters.search}%,description.ilike.%${filters.search}%`);
    }

    if (filters.compatibility && filters.compatibility.length > 0) {
      query = query.contains('compatibility_tags', filters.compatibility);
    }

    // Apply sorting
    switch (filters.sortBy) {
      case 'newest':
        query = query.order('created_at', { ascending: false });
        break;
      case 'price_asc':
        query = query.order('price_usd', { ascending: true });
        break;
      case 'price_desc':
        query = query.order('price_usd', { ascending: false });
        break;
      case 'popular':
        query = query.order('download_count', { ascending: false });
        break;
      default:
        query = query.order('created_at', { ascending: false });
    }

    const { data, error } = await query;

    if (error) {
      console.error('Error fetching packs:', error);
    } else {
      setPacks(data || []);
    }
    
    setIsLoading(false);
  }, [filters, supabase]);

  useEffect(() => {
    fetchPacks();
  }, [fetchPacks]);

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-3xl sm:text-4xl font-bold text-text-primary mb-4">
            AI Prompt Marketplace
          </h1>
          <p className="text-text-secondary max-w-2xl">
            Discover professionally crafted prompt packs for every AI model and use case. 
            From business automation to creative art generation.
          </p>
        </div>

        {/* Filters */}
        <FilterBar
          onFilterChange={setFilters}
          categories={CATEGORIES}
          compatibilityOptions={COMPATIBILITY_OPTIONS}
        />

        {/* Results */}
        {isLoading ? (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
            <span className="ml-3 text-text-secondary">Loading packs...</span>
          </div>
        ) : packs.length > 0 ? (
          <>
            <div className="flex items-center justify-between mb-6">
              <p className="text-text-secondary">
                Showing <span className="text-text-primary font-medium">{packs.length}</span> packs
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {packs.map((pack) => (
                <ProductCard key={pack.id} pack={pack} showBadge />
              ))}
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <div className="w-16 h-16 rounded-2xl bg-surface-light flex items-center justify-center mb-4">
              <Package className="w-8 h-8 text-text-muted" />
            </div>
            <h3 className="text-xl font-semibold text-text-primary mb-2">
              No packs found
            </h3>
            <p className="text-text-secondary max-w-md">
              Try adjusting your filters or search terms to find what you&apos;re looking for.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
