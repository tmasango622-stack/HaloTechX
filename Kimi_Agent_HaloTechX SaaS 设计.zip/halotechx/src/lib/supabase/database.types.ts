export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          display_name: string | null;
          email: string;
          avatar_url: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          display_name?: string | null;
          email: string;
          avatar_url?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          display_name?: string | null;
          email?: string;
          avatar_url?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      prompt_packs: {
        Row: {
          id: string;
          title: string;
          slug: string;
          description: string;
          category: string;
          prompt_count: number;
          preview_text: string | null;
          price_usd: number;
          compatibility_tags: string[];
          file_path: string;
          file_size_bytes: number | null;
          download_count: number;
          is_featured: boolean;
          is_published: boolean;
          seo_title: string | null;
          seo_description: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          title: string;
          slug: string;
          description: string;
          category: string;
          prompt_count?: number;
          preview_text?: string | null;
          price_usd: number;
          compatibility_tags?: string[];
          file_path: string;
          file_size_bytes?: number | null;
          download_count?: number;
          is_featured?: boolean;
          is_published?: boolean;
          seo_title?: string | null;
          seo_description?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          title?: string;
          slug?: string;
          description?: string;
          category?: string;
          prompt_count?: number;
          preview_text?: string | null;
          price_usd?: number;
          compatibility_tags?: string[];
          file_path?: string;
          file_size_bytes?: number | null;
          download_count?: number;
          is_featured?: boolean;
          is_published?: boolean;
          seo_title?: string | null;
          seo_description?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      transactions: {
        Row: {
          id: string;
          user_id: string | null;
          pack_id: string | null;
          gateway: 'paynow' | 'flutterwave' | 'nowpayments';
          status: 'pending' | 'confirmed' | 'failed' | 'timeout' | 'refunded';
          amount: number;
          currency: string;
          gateway_transaction_id: string | null;
          signature_hash: string | null;
          poll_count: number;
          last_polled_at: string | null;
          metadata: Json;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id?: string | null;
          pack_id?: string | null;
          gateway: 'paynow' | 'flutterwave' | 'nowpayments';
          status?: 'pending' | 'confirmed' | 'failed' | 'timeout' | 'refunded';
          amount: number;
          currency?: string;
          gateway_transaction_id?: string | null;
          signature_hash?: string | null;
          poll_count?: number;
          last_polled_at?: string | null;
          metadata?: Json;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string | null;
          pack_id?: string | null;
          gateway?: 'paynow' | 'flutterwave' | 'nowpayments';
          status?: 'pending' | 'confirmed' | 'failed' | 'timeout' | 'refunded';
          amount?: number;
          currency?: string;
          gateway_transaction_id?: string | null;
          signature_hash?: string | null;
          poll_count?: number;
          last_polled_at?: string | null;
          metadata?: Json;
          created_at?: string;
          updated_at?: string;
        };
      };
      user_downloads: {
        Row: {
          id: string;
          user_id: string;
          pack_id: string;
          transaction_id: string;
          downloaded_at: string;
          ip_address: string | null;
          user_agent: string | null;
        };
        Insert: {
          id?: string;
          user_id: string;
          pack_id: string;
          transaction_id: string;
          downloaded_at?: string;
          ip_address?: string | null;
          user_agent?: string | null;
        };
        Update: {
          id?: string;
          user_id?: string;
          pack_id?: string;
          transaction_id?: string;
          downloaded_at?: string;
          ip_address?: string | null;
          user_agent?: string | null;
        };
      };
    };
    Functions: {
      increment_download_count: {
        Args: { pack_id: string };
        Returns: void;
      };
    };
    Enums: {
      payment_status: 'pending' | 'confirmed' | 'failed' | 'timeout' | 'refunded';
      payment_gateway: 'paynow' | 'flutterwave' | 'nowpayments';
    };
  };
}
