import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { nanoid } from 'nanoid';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function generateSlug(title: string): string {
  const normalized = title
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-');
  
  const uniqueId = nanoid(6);
  return `${normalized}-${uniqueId}`;
}

export function normalizeTitle(title: string): string {
  return title
    .toLowerCase()
    .trim()
    .replace(/[^\w\s]/g, '')
    .replace(/\s+/g, ' ');
}

export function generateSEOFields(title: string, description: string) {
  return {
    seo_title: `${title} - HaloTechX AI Prompts`,
    seo_description: description.slice(0, 160).trim(),
  };
}

export function formatPrice(price: number, currency: string = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
  }).format(price);
}

export function formatCompactNumber(number: number): string {
  return new Intl.NumberFormat('en-US', {
    notation: 'compact',
    maximumFractionDigits: 1,
  }).format(number);
}

export function formatDate(dateString: string): string {
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(dateString));
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength).trim() + '...';
}

export function getCategoryColor(category: string): string {
  const colors: Record<string, string> = {
    Business: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    Creative: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    Development: 'bg-green-500/20 text-green-400 border-green-500/30',
    Marketing: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
    'Data Science': 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
    Writing: 'bg-pink-500/20 text-pink-400 border-pink-500/30',
    Default: 'bg-slate-500/20 text-slate-400 border-slate-500/30',
  };
  return colors[category] || colors.Default;
}

export function getCompatibilityIcon(model: string): string {
  const icons: Record<string, string> = {
    ChatGPT: '⚡',
    'GPT-4': '🔷',
    Claude: '🟣',
    Midjourney: '🎨',
    'DALL-E': '🖼️',
    'Stable Diffusion': '🌟',
    'GitHub Copilot': '👨‍💻',
    Jasper: '📝',
    'Code Interpreter': '🐍',
  };
  return icons[model] || '🤖';
}

export function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function generateSignatureHash(payload: string, secret: string): string {
  const crypto = require('crypto');
  return crypto
    .createHmac('sha256', secret)
    .update(payload)
    .digest('hex');
}

export function verifySignature(payload: string, signature: string, secret: string): boolean {
  const expected = generateSignatureHash(payload, secret);
  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expected)
  );
}
