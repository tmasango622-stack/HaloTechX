// ============================================
// HaloTechX Type Definitions
// ============================================

export interface Profile {
  id: string;
  display_name: string | null;
  email: string;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface PromptPack {
  id: string;
  title: string;
  slug: string;
  description: string;
  category: string;
  prompt_count: number;
  preview_text: string | null;
  price_usd: number;
  compatibility_tags: string[];
  file_path: string;
  file_size_bytes: number | null;
  download_count: number;
  is_featured: boolean;
  is_published: boolean;
  seo_title: string | null;
  seo_description: string | null;
  created_at: string;
  updated_at: string;
}

export type PaymentStatus = 'pending' | 'confirmed' | 'failed' | 'timeout' | 'refunded';
export type PaymentGateway = 'paynow' | 'flutterwave' | 'nowpayments';

export interface Transaction {
  id: string;
  user_id: string | null;
  pack_id: string | null;
  gateway: PaymentGateway;
  status: PaymentStatus;
  amount: number;
  currency: string;
  gateway_transaction_id: string | null;
  signature_hash: string | null;
  poll_count: number;
  last_polled_at: string | null;
  metadata: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface UserDownload {
  id: string;
  user_id: string;
  pack_id: string;
  transaction_id: string;
  downloaded_at: string;
  ip_address: string | null;
  user_agent: string | null;
}

export interface PackWithOwnership extends PromptPack {
  is_owned?: boolean;
  transaction_id?: string;
}

export interface FilterOptions {
  category?: string;
  minPrice?: number;
  maxPrice?: number;
  compatibility?: string[];
  sortBy?: 'newest' | 'price_asc' | 'price_desc' | 'popular';
  search?: string;
}

export interface PaymentInitRequest {
  pack_id: string;
  gateway: PaymentGateway;
  return_url?: string;
}

export interface PaymentInitResponse {
  success: boolean;
  transaction_id: string;
  gateway_url?: string;
  payment_data?: Record<string, unknown>;
  error?: string;
}

export interface ZapierPackPayload {
  title: string;
  description: string;
  category: string;
  prompt_count: number;
  preview_text?: string;
  price_usd: number;
  compatibility_tags?: string[];
  file_path: string;
  file_size_bytes?: number;
  seo_title?: string;
  seo_description?: string;
  is_featured?: boolean;
}

export interface SignedUrlResponse {
  url: string;
  expires_at: string;
}

export interface DashboardStats {
  total_purchases: number;
  total_spent: number;
  downloads_available: number;
  recent_downloads: UserDownload[];
}
