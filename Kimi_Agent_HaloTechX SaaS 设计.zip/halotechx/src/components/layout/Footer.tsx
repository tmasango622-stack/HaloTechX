import Link from 'next/link';
import { Sparkles, Twitter, Github, Mail } from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    Product: [
      { label: 'Marketplace', href: '/marketplace' },
      { label: 'Featured Packs', href: '/marketplace?featured=true' },
      { label: 'New Arrivals', href: '/marketplace?sort=newest' },
    ],
    Company: [
      { label: 'About', href: '/about' },
      { label: 'Blog', href: '/blog' },
      { label: 'Careers', href: '/careers' },
    ],
    Support: [
      { label: 'Help Center', href: '/support' },
      { label: 'Contact', href: '/contact' },
      { label: 'Terms', href: '/terms' },
      { label: 'Privacy', href: '/privacy' },
    ],
  };

  const socialLinks = [
    { icon: Twitter, href: 'https://twitter.com/halotechx', label: 'Twitter' },
    { icon: Github, href: 'https://github.com/halotechx', label: 'GitHub' },
    { icon: Mail, href: 'mailto:support@halotechx.com', label: 'Email' },
  ];

  return (
    <footer className="bg-surface border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand */}
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-text-primary">
                HaloTechX
              </span>
            </Link>
            <p className="text-text-secondary text-sm max-w-xs mb-6">
              Premium AI prompt packs for professionals. Supercharge your workflow with expertly crafted prompts.
            </p>
            <div className="flex items-center gap-4">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-lg bg-surface-light hover:bg-border flex items-center justify-center text-text-muted hover:text-text-primary transition-all"
                  aria-label={social.label}
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h3 className="text-text-primary font-semibold mb-4">{category}</h3>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="text-text-secondary hover:text-text-primary transition-colors text-sm"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom */}
        <div className="mt-12 pt-8 border-t border-border flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-text-muted text-sm">
            {currentYear} HaloTechX. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <Link href="/terms" className="text-text-muted hover:text-text-secondary text-sm transition-colors">
              Terms of Service
            </Link>
            <Link href="/privacy" className="text-text-muted hover:text-text-secondary text-sm transition-colors">
              Privacy Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
