'use client';

import Link from 'next/link';
import { PromptPack } from '@/types';
import { getCategoryColor, formatPrice, truncateText } from '@/lib/utils';
import { Download, Sparkles, FileText } from 'lucide-react';

interface ProductCardProps {
  pack: PromptPack;
  showBadge?: boolean;
}

export function ProductCard({ pack, showBadge = false }: ProductCardProps) {
  return (
    <Link href={`/product/${pack.slug}`}>
      <div className="group relative h-full">
        {/* Glassmorphism Card */}
        <div className="h-full glass rounded-2xl p-6 card-hover overflow-hidden">
          {/* Background gradient on hover */}
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          
          {/* Content */}
          <div className="relative z-10">
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getCategoryColor(pack.category)}`}>
                {pack.category}
              </span>
              {showBadge && pack.is_featured && (
                <span className="flex items-center gap-1 px-2 py-1 bg-amber-500/20 text-amber-400 rounded-full text-xs font-medium">
                  <Sparkles className="w-3 h-3" />
                  Featured
                </span>
              )}
            </div>

            {/* Title */}
            <h3 className="text-lg font-semibold text-text-primary mb-2 group-hover:text-primary transition-colors line-clamp-2">
              {pack.title}
            </h3>

            {/* Description */}
            <p className="text-text-secondary text-sm mb-4 line-clamp-2">
              {truncateText(pack.description, 120)}
            </p>

            {/* Stats */}
            <div className="flex items-center gap-4 mb-4 text-sm text-text-muted">
              <div className="flex items-center gap-1.5">
                <FileText className="w-4 h-4" />
                <span>{pack.prompt_count} prompts</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Download className="w-4 h-4" />
                <span>{pack.download_count.toLocaleString()}</span>
              </div>
            </div>

            {/* Compatibility Tags */}
            <div className="flex flex-wrap gap-1.5 mb-4">
              {pack.compatibility_tags.slice(0, 3).map((tag) => (
                <span
                  key={tag}
                  className="px-2 py-0.5 bg-surface-light text-text-muted rounded text-xs"
                >
                  {tag}
                </span>
              ))}
              {pack.compatibility_tags.length > 3 && (
                <span className="px-2 py-0.5 bg-surface-light text-text-muted rounded text-xs">
                  +{pack.compatibility_tags.length - 3}
                </span>
              )}
            </div>

            {/* Price */}
            <div className="flex items-center justify-between pt-4 border-t border-border">
              <span className="text-2xl font-bold text-text-primary">
                {formatPrice(pack.price_usd)}
              </span>
              <span className="text-sm text-primary font-medium group-hover:underline">
                View Details →
              </span>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}
