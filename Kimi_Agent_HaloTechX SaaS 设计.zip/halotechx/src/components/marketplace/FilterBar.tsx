'use client';

import { useState } from 'react';
import { FilterOptions } from '@/types';
import { Search, SlidersHorizontal, X } from 'lucide-react';

interface FilterBarProps {
  onFilterChange: (filters: FilterOptions) => void;
  categories: string[];
  compatibilityOptions: string[];
}

export function FilterBar({ onFilterChange, categories, compatibilityOptions }: FilterBarProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [filters, setFilters] = useState<FilterOptions>({
    search: '',
    category: '',
    sortBy: 'newest',
  });

  const handleChange = (key: keyof FilterOptions, value: any) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  const clearFilters = () => {
    const cleared = { sortBy: 'newest' as const };
    setFilters(cleared);
    onFilterChange(cleared);
  };

  const hasActiveFilters = filters.category || filters.search || filters.compatibility?.length;

  return (
    <div className="bg-surface border border-border rounded-xl p-4 mb-8">
      {/* Main Filter Row */}
      <div className="flex flex-col sm:flex-row gap-4">
        {/* Search */}
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
          <input
            type="text"
            placeholder="Search prompt packs..."
            value={filters.search || ''}
            onChange={(e) => handleChange('search', e.target.value)}
            className="w-full pl-10 pr-4 py-2.5"
          />
        </div>

        {/* Category Dropdown */}
        <select
          value={filters.category || ''}
          onChange={(e) => handleChange('category', e.target.value)}
          className="sm:w-40 py-2.5"
        >
          <option value="">All Categories</option>
          {categories.map((cat) => (
            <option key={cat} value={cat}>
              {cat}
            </option>
          ))}
        </select>

        {/* Sort Dropdown */}
        <select
          value={filters.sortBy}
          onChange={(e) => handleChange('sortBy', e.target.value)}
          className="sm:w-40 py-2.5"
        >
          <option value="newest">Newest</option>
          <option value="price_asc">Price: Low to High</option>
          <option value="price_desc">Price: High to Low</option>
          <option value="popular">Most Popular</option>
        </select>

        {/* Filter Toggle */}
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className={`flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border transition-all ${
            isExpanded 
              ? 'bg-primary/10 border-primary text-primary' 
              : 'bg-surface-light border-border text-text-secondary hover:text-text-primary'
          }`}
        >
          <SlidersHorizontal className="w-4 h-4" />
          <span className="hidden sm:inline">Filters</span>
        </button>

        {/* Clear Filters */}
        {hasActiveFilters && (
          <button
            onClick={clearFilters}
            className="flex items-center justify-center gap-2 px-4 py-2.5 text-text-muted hover:text-text-secondary transition-colors"
          >
            <X className="w-4 h-4" />
            <span className="hidden sm:inline">Clear</span>
          </button>
        )}
      </div>

      {/* Expanded Filters */}
      {isExpanded && (
        <div className="mt-4 pt-4 border-t border-border">
          <div className="flex flex-col gap-4">
            <div>
              <label className="text-sm text-text-secondary mb-2 block">Compatibility</label>
              <div className="flex flex-wrap gap-2">
                {compatibilityOptions.map((option) => (
                  <button
                    key={option}
                    onClick={() => {
                      const current = filters.compatibility || [];
                      const updated = current.includes(option)
                        ? current.filter((c) => c !== option)
                        : [...current, option];
                      handleChange('compatibility', updated);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                      filters.compatibility?.includes(option)
                        ? 'bg-primary text-white'
                        : 'bg-surface-light text-text-secondary hover:text-text-primary'
                    }`}
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-1">
                <label className="text-sm text-text-secondary mb-2 block">Min Price</label>
                <input
                  type="number"
                  placeholder="$0"
                  value={filters.minPrice || ''}
                  onChange={(e) => handleChange('minPrice', e.target.value ? parseFloat(e.target.value) : undefined)}
                  className="w-full"
                />
              </div>
              <div className="flex-1">
                <label className="text-sm text-text-secondary mb-2 block">Max Price</label>
                <input
                  type="number"
                  placeholder="$1000"
                  value={filters.maxPrice || ''}
                  onChange={(e) => handleChange('maxPrice', e.target.value ? parseFloat(e.target.value) : undefined)}
                  className="w-full"
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
